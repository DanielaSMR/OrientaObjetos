public class Principal {
    public static void main(String[] args) {
        Raices ecuacion=new Raices(1,4,4); //creamos el objeto
        ecuacion.calcular(); //Calculamos
        }
}
